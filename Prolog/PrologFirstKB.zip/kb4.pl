student(joe).
student(tim).
student(bill).
plays76(andy).
studies(joe,andy).
studies(joe,tim).
studies(bill,tim).
