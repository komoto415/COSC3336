angry(andy).
calm(andy).
calm(joe).
plays76(andy):- angry(andy).
listensMusic(andy):- calm(andy).
listensMusic(joe):- calm(joe).
