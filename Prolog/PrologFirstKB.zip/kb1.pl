student(joe).
student(tim).
student(bill).
plays76(andy).
school.
